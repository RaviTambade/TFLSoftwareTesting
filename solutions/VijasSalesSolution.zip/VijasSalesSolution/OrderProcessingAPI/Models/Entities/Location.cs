namespace Transflower.MembershipRolesMgmt.Models.Entities;

public class Location{
    public int UserId {get;set;}
    public double Longitude {get;set;}
    public double Latitude {get;set;}
}