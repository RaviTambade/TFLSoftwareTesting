namespace Transflower.MembershipRolesMgmt.Models.Responses;

public class UserDetails
{
    public int Id { get; set; }
    public string? FullName { get; set; }
    public string? ImageUrl { get; set; }
}
