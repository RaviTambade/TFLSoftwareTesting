namespace Transflower.MembershipRolesMgmt.Models.Requests;

public class PasswordDetails
{
    public string? OldPassword { get; set; }
    public string? NewPassword { get; set; }
}
