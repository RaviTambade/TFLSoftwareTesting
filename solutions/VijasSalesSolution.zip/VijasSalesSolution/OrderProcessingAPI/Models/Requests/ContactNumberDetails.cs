namespace Transflower.MembershipRolesMgmt.Models.Requests;

public class ContactNumberDetails
{
    public string? NewContactNumber { get; set; }
    public string? Password { get; set; }
}
