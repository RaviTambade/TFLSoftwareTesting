using Transflower.MembershipRolesMgmt.Repositories.Interfaces;
namespace Transflower.MembershipRolesMgmt.Services.Interfaces;
public interface IRoleService : IRoleRepository { }