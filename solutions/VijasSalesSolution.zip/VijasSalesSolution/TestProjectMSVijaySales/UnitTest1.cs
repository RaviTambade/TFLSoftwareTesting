namespace TestProjectMSVijaySales
{

    //Testing Framework used : MSTest
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}