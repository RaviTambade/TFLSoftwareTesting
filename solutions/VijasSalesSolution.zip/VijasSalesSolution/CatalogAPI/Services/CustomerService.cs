﻿namespace CatalogAPI.Services
{
    public class CustomerService
    {
    }
}
