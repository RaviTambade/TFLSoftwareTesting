﻿
using CatalogAPI.Models.Entities;
using CatalogAPI.Repositories.Interfaces;
namespace CatalogAPI.Services.Interfaces
{
    public interface ICustomerService : ICustomerRepository
    {

       
    }
}
