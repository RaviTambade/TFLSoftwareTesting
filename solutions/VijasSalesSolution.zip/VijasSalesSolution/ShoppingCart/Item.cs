﻿namespace ShoppingCart
{
    public class Item
    {

    }
}
