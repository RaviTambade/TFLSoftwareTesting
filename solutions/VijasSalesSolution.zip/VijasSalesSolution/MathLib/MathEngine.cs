﻿namespace MathLib
{
    public class MathEngine
    {
        public int Addition(int x, int y)
        {
            return  x * y;
        }

        public int Subtract(int x, int y)
        {
            return x-y;
        }
    }
}
